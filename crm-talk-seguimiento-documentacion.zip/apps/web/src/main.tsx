import { QueryClient, QueryClientProvider, useQuery } from "@tanstack/react-query";
import { Search, ShieldAlert } from "lucide-react";
import { StrictMode, type ReactNode } from "react";
import { createRoot } from "react-dom/client";
import { createBrowserRouter, RouterProvider } from "react-router";
import { Layout } from "./components/Layout";
import { EmptyState } from "./components/ui";
import { ApiError, api, avisarEscrituras, baseOcupada, esperaReintento } from "./lib/api";
import { Campaign } from "./pages/Campaign";
import { BulkUpload } from "./pages/BulkUpload";
import { Metas } from "./pages/Metas";
import { ChangePassword } from "./pages/ChangePassword";
import { Client } from "./pages/Client";
import { Home } from "./pages/Home";
import { Login } from "./pages/Login";
import { Presentation } from "./pages/Presentation";
import { SeguimientoDocumentacion } from "./pages/SeguimientoDocumentacion";
import { Settings } from "./pages/Settings";
import { Upload } from "./pages/Upload";
import { Users } from "./pages/Users";
import "./styles.css";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      // Un 401/403 no se arregla reintentando. Con la base ocupada se reintenta más veces y más despacio (4, 8, 12… s):
      // se libera sola en unos segundos.
      retry: (count, err) => !(err instanceof ApiError && [401, 403].includes(err.status)) && count < (baseOcupada(err) ? 5 : 2),
      retryDelay: (count, err) => esperaReintento(count + 1, err),
    },
  },
});

/* Después de cualquier cambio guardado (carga, meta, nombres de agentes…) se vuelven a pedir las cifras:
   lo que ya estaba en memoria nunca se queda viejo aunque se reutilice unos minutos. */
const CIFRAS = new Set(["analysis", "historico", "presentacion", "cliente"]);
avisarEscrituras(() => void queryClient.invalidateQueries({ predicate: (q) => CIFRAS.has(String(q.queryKey[0])) }));

/* Si la sesión vence mientras la app está abierta, vuelve a la pantalla de entrada. */
queryClient.getQueryCache().subscribe((e) => {
  const err = e.query.state.error;
  if (e.type === "updated" && err instanceof ApiError && err.status === 401 && e.query.queryKey[0] !== "me") {
    void queryClient.invalidateQueries({ queryKey: ["me"] });
  }
});

/* Un archivo soltado fuera de una zona de carga no debe abrirse ni descargarse en el navegador. */
for (const type of ["dragover", "drop"] as const) window.addEventListener(type, (e) => e.preventDefault());

/** Muestra el login si no hay sesión y la pantalla de cambio de contraseña si es obligatoria. */
function SessionGate({ children }: { children: ReactNode }) {
  const me = useQuery({ queryKey: ["me"], queryFn: api.me, staleTime: 5 * 60_000 });
  const done = () => {
    queryClient.removeQueries({ predicate: (q) => q.queryKey[0] !== "me" });
    void me.refetch();
  };

  if (me.isPending) {
    return <div className="flex min-h-dvh items-center justify-center text-sm text-slate-500">Verificando tu sesión…</div>;
  }
  if (me.isError) {
    if (me.error instanceof ApiError && me.error.status === 401) return <Login onDone={done} />;
    return (
      <div className="flex min-h-dvh items-center justify-center p-6">
        <div className="max-w-md text-center">
          <ShieldAlert className="mx-auto mb-4 size-10 text-accent-500" aria-hidden />
          <h1 className="text-lg font-semibold">No pudimos abrir el CRM</h1>
          <p className="mt-2 text-sm text-slate-500">{me.error.message}</p>
          <button onClick={() => location.reload()} className="mt-6 rounded-xl bg-brand-500 px-4 py-2 text-sm font-medium text-white hover:bg-brand-600">
            Volver a intentar
          </button>
        </div>
      </div>
    );
  }
  if (me.data.mustChangePassword) return <ChangePassword forced />;
  return <>{children}</>;
}

const router = createBrowserRouter([
  {
    element: (
      <SessionGate>
        <Layout />
      </SessionGate>
    ),
    children: [
      { index: true, element: <Home /> },
      { path: "campanas/:code/:tab?", element: <Campaign /> },
      { path: "cliente", element: <Client /> },
      { path: "seguimiento-documentacion", element: <SeguimientoDocumentacion /> },
      { path: "carga", element: <Upload /> },
      { path: "carga/zip", element: <BulkUpload /> },
      { path: "carga/metas", element: <Metas /> },
      { path: "presentacion", element: <Presentation /> },
      { path: "reportes", element: <Presentation /> },
      { path: "configuracion", element: <Settings /> },
      { path: "configuracion/usuarios", element: <Users /> },
      { path: "cuenta/clave", element: <ChangePassword /> },
      {
        path: "*",
        element: (
          <EmptyState icon={Search} title="Página no encontrada">
            Esa dirección no existe. Usa el menú para volver a una sección.
          </EmptyState>
        ),
      },
    ],
  },
]);

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
    </QueryClientProvider>
  </StrictMode>,
);
