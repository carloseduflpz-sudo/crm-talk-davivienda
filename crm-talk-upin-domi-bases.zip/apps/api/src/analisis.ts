/* Análisis de una campaña en un mes, calculado en la base con los archivos VIGENTES.
   Definiciones (las mismas de la versión 1):
   - Aprobación = aprobadas ÷ evaluadas (aprobadas + rechazadas + no desembolsadas, estas solo en CDC y Extra).
   - Contactabilidad = llamadas con contacto efectivo ÷ llamadas. Contacto efectivo =
     venta + negativo (+ no efectivo, según la regla de la campaña; por defecto sí).
   - Registros = clientes (NIU) distintos llamados.
   - Penetración = clientes con venta en VICI ÷ clientes únicos de la base del mes.
   - Cumplimiento = ventas de la sábana del mes ÷ meta; ritmo = ventas ÷ día del mes de la
     última venta; proyección = ritmo × días del mes. */
import {
  DEFAULT_WORK_DAYS,
  GOAL_UNIT,
  businessDays,
  countsForGoal,
  daysInMonth,
  isCampaignCode,
  suggestedHolidays,
  type CampaignAnalysis,
  type CampaignCode,
  type Count,
  type MonthSummary,
  type SaleClass,
} from "@crm/core";
import { loadAgentNaming } from "./agentes";
import { audit } from "./audit";
import type { Env } from "./env";
import { HttpError, json, readJson, requireString, type Router } from "./http";
import { leerOficial } from "./oficial";
import type { Oficial } from "@crm/core";
import { parteClave, Resultados } from "./resultados";

interface CurrentUpload {
  id: string;
  dataset: string;
  kind: string;
  month: string;
  rows_valid: number;
  version: number;
  created_at: number;
  created_by: string;
  is_addition: number;
  label: string | null;
}

const pct = (a: number, b: number) => (b ? (a / b) * 100 : 0);

interface GoalRow {
  sales_goal: number | null;
  agents: number | null;
  counted_statuses: string | null;
  work_days: string | null;
  holidays: string | null;
}
/** Lista JSON guardada (o null si no hay). */
function parseList(v: string | null | undefined): string[] | null {
  if (!v) return null;
  try {
    const x = JSON.parse(v) as unknown;
    return Array.isArray(x) ? x.filter((s): s is string => typeof s === "string") : null;
  } catch {
    return null;
  }
}
function parseDays(v: string | null | undefined): number[] {
  const d = (v ?? "")
    .split(",")
    .map(Number)
    .filter((x) => Number.isInteger(x) && x >= 0 && x <= 6);
  return d.length ? [...new Set(d)].sort() : [...DEFAULT_WORK_DAYS];
}
const n = (v: unknown) => Number(v ?? 0);
/** Estatus exactamente "PENDIENTE POR REQUISITO" (sin importar mayúsculas ni espacios de más). */
const PEND_REQ = (col: string) => `UPPER(TRIM(${col})) = 'PENDIENTE POR REQUISITO'`;
/** Día (AAAA-MM-DD, hora de El Salvador, UTC−6) en que se cargó un archivo. */
const diaCarga = (ms: number) => new Date(ms - 6 * 3600_000).toISOString().slice(0, 10);
const placeholders = (k: number) => Array.from({ length: k }, () => "?").join(", ");

/** Ventas y monto acumulados por día del mes (solo fechas de ese mes). */
function acumulado(month: string, porDia: { date: string; ventas: number; monto: number }[]): { ventas: number[]; monto: number[] } {
  const days = daysInMonth(month);
  const v = new Array<number>(days).fill(0);
  const m = new Array<number>(days).fill(0);
  for (const d of porDia) {
    if (!d.date.startsWith(month)) continue;
    const i = Number(d.date.slice(8, 10)) - 1;
    if (i >= 0 && i < days) (v[i]! += d.ventas), (m[i]! += d.monto);
  }
  for (let i = 1; i < days; i++) (v[i]! += v[i - 1]!), (m[i]! += m[i - 1]!);
  return { ventas: v, monto: m.map((x) => Math.round(x * 100) / 100) };
}

/**
 * Documentos pedidos, unificados: cada venta pendiente cuenta UNA sola vez, en la combinación exacta de documentos
 * que debe ("Boleta + Recibo" es su propio grupo, distinto de "Boleta" sola). Así la suma da el total de pendientes.
 * Los documentos escritos distinto solo por mayúsculas, tildes, espacios o el orden ("recibo y boleta") se juntan.
 */
export function agruparDocumentos(textos: (string | null)[]): { grupos: string[]; porDocumento: { label: string; clientes: number }[] } {
  const clave = (s: string) =>
    s
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toUpperCase();
  const partesDe = (t: string | null) => (t ? t.split(/\s*(?:[,;\/+\n]|\s-\s|\sy\s)\s*/i).map((x) => x.trim()).filter((x) => x.length > 1) : []);
  // Cada documento se muestra como viene escrito la primera vez.
  const escrito = new Map<string, string>();
  for (const t of textos) for (const p of partesDe(t)) if (!escrito.has(clave(p))) escrito.set(clave(p), p.replace(/\s+/g, " "));
  const grupos = textos.map((t) => {
    const claves = [...new Set(partesDe(t).map(clave))].sort((x, y) => x.localeCompare(y, "es"));
    return claves.length ? claves.map((k) => escrito.get(k)!).join(" + ") : "Sin documento especificado";
  });
  const m = new Map<string, number>();
  for (const g of grupos) m.set(g, (m.get(g) ?? 0) + 1);
  const porDocumento = [...m.entries()].map(([label, clientes]) => ({ label, clientes })).sort((x, y) => y.clientes - x.clientes || x.label.localeCompare(y.label, "es"));
  return { grupos, porDocumento };
}

/** Días de un mes (del día desde al día hasta) para comparar meses al mismo corte. */
export interface Dias {
  desde: number;
  hasta: number;
}

/** Fechas del rango en ese mes; null si es el mes completo (del 1 al último día). */
export function rangoDelMes(month: string, dias: Dias): { desde: number; hasta: number; d1: string; d2: string } | null {
  const [y, m] = month.split("-").map(Number) as [number, number];
  const ultimo = new Date(Date.UTC(y, m, 0)).getUTCDate();
  const desde = Math.min(Math.max(1, Math.trunc(dias.desde)), ultimo);
  const hasta = Math.min(Math.max(desde, Math.trunc(dias.hasta)), ultimo);
  if (desde === 1 && hasta === ultimo) return null;
  const dia = (d: number) => `${month}-${String(d).padStart(2, "0")}`;
  return { desde, hasta, d1: dia(desde), d2: dia(hasta) };
}

/** Análisis de la campaña; si ya se calculó con los mismos archivos y la misma configuración, sale de lo guardado. */
export function analyzeCampaign(
  env: Env,
  campaign: string,
  requestedMonth: string | null,
  agente: string | null = null,
  resultados: Resultados = new Resultados(env),
  dias: Dias | null = null,
): Promise<CampaignAnalysis> {
  const rango = dias ? `-d${dias.desde}-${dias.hasta}` : "";
  return resultados.obtener(`analisis/${campaign}/${requestedMonth ?? "ultimo"}${rango}/${parteClave(agente)}.json`, () =>
    calcularAnalisis(env, campaign, requestedMonth, agente, dias),
    campaign,
  );
}

async function calcularAnalisis(env: Env, campaign: string, requestedMonth: string | null, agente: string | null, dias: Dias | null = null): Promise<CampaignAnalysis> {
  const db = env.DB;
  /* Velocidad: cada consulta es un viaje del Worker a la base. Lo que no depende de nada se pide junto
     (nombres de agentes, archivos vigentes, regla de contacto y metas) y después cada sección va en paralelo. */
  const [naming, { results: current }, ruleRow, { results: goalRows }] = await Promise.all([
    // Nombre homologado del agente (la herramienta une sola las formas distintas de escribir a la misma persona).
    loadAgentNaming(env, campaign),
    db
      .prepare("SELECT id, dataset, kind, month, rows_valid, version, created_at, created_by, is_addition, label FROM uploads WHERE campaign = ? AND is_current = 1")
      .bind(campaign)
      .all<CurrentUpload>(),
    db.prepare("SELECT contact_rule FROM campaigns WHERE code = ?").bind(campaign).first<{ contact_rule: string }>(),
    db.prepare("SELECT month, sales_goal, agents, counted_statuses, work_days, holidays FROM goals WHERE campaign = ?").bind(campaign).all<GoalRow & { month: string }>(),
  ]);
  const agentLabel = naming.sql;
  // Filtro opcional por agente: se agrega a cada consulta de ventas, llamadas y CRM.
  const fa = (col: string) => (agente ? ` AND ${agentLabel(col)} = ?` : "");
  const fb: string[] = agente ? [agente] : [];
  const months = [...new Set(current.map((u) => u.month))].sort().reverse();
  const month = requestedMonth && months.includes(requestedMonth) ? requestedMonth : (months[0] ?? null);
  const ofMonth = current.filter((u) => u.month === month);
  const sabana = ofMonth.find((u) => u.kind === "sabana");
  const tipif = ofMonth.find((u) => u.kind === "tipif");
  const crm = ofMonth.find((u) => u.kind === "ventas");
  const bases = ofMonth.filter((u) => u.kind === "base");

  /* Rango de días dentro del mes (para comparar meses al mismo corte): ventas, llamadas y CRM solo con fecha en el
     rango. Desde el día 1 también entra lo que trae fecha anterior al mes o no trae fecha (la cosecha de la
     sábana), así "del 1 al 31" es igual a todo el mes. Las fechas van escritas en la consulta: son números ya validados. */
  const rango = month && dias ? rangoDelMes(month, dias) : null;
  const enRango = (col: string) =>
    rango ? ` AND (substr(COALESCE(${col}, ''), 1, 10) BETWEEN '${rango.d1}' AND '${rango.d2}'${rango.desde === 1 ? ` OR COALESCE(${col}, '') < '${month}-01'` : ""})` : "";
  /** Lo mismo, en cada mes (u.month) con los mismos días: para las gráficas que comparan meses. */
  const porMesEnRango = (col: string) =>
    rango
      ? ` AND ((substr(${col}, 1, 7) = u.month AND CAST(substr(${col}, 9, 2) AS INTEGER) BETWEEN ${rango.desde} AND ${rango.hasta})${rango.desde === 1 ? ` OR COALESCE(${col}, '') < u.month || '-01'` : ""})`
      : "";
  const fs = (p: string) => fa(`${p}executive`) + enRango(`${p}sale_date`);
  const fl = (p: string) => fa(`${p}agent`) + enRango(`${p}called_at`);
  const fc = (p: string) => fa(`${p}agent`) + enRango(`${p}entered_at`);

  const rule = ruleRow?.contact_rule === "sin_no_efectivo" ? "sin_no_efectivo" : "con_no_efectivo";
  const efectivoSql = rule === "con_no_efectivo" ? "call_class IN ('venta','negativo','no_efectivo')" : "call_class IN ('venta','negativo')";

  const out: CampaignAnalysis = {
    campaign,
    month,
    months,
    agente,
    dias: rango ? { desde: rango.desde, hasta: rango.hasta, d1: rango.d1, d2: rango.d2 } : null,
    agentes: [],
    agentesUnidos: [],
    loaded: ofMonth.map((u) => ({ dataset: u.dataset, kind: u.kind, rows: u.rows_valid, version: u.version, createdAt: u.created_at, createdBy: u.created_by })),
    fechas: { hasta: null, fuera: [] },
    ventas: null,
    base: null,
    llamadas: null,
    crm: null,
    cumplimiento: {
      meta: null,
      agentes: null,
      metaPorAgente: null,
      unidad: isCampaignCode(campaign) ? GOAL_UNIT[campaign] : "ventas",
      ventas: 0,
      ventasTotales: 0,
      operaciones: 0,
      operacionesTotales: 0,
      aprobadas: 0,
      avance: null,
      faltan: null,
      fechaCorte: null,
      fechasPosteriores: null,
      diaDelMes: 0,
      diasDelMes: 0,
      diasRestantes: 0,
      ritmoDiario: 0,
      proyeccion: 0,
      ritmoNecesario: null,
      esperado: null,
      avanceMTD: null,
      cosecha: { valor: 0, operaciones: 0, porMes: [] },
      yaContadas: { valor: 0, operaciones: 0 },
      porAgente: [],
      config: { estatus: [], estatusPorDefecto: true, diasSemana: [...DEFAULT_WORK_DAYS], feriados: [] },
      estatusDisponibles: [],
      feriadosSugeridos: month ? suggestedHolidays(month) : [],
    },
  };

  /* ---------- fechas: hasta qué día llegan los datos y filas de otros meses ---------- */
  const fechasP = (async () => {
    if (month) {
      type Dated = ["sabana" | "tipif" | "ventas", CurrentUpload | undefined, string, string];
      const dated = (
        [
          ["sabana", sabana, "bank_sales", "sale_date"],
          ["tipif", tipif, "calls", "called_at"],
          ["ventas", crm, "crm_sales", "entered_at"],
        ] as Dated[]
      ).filter((x): x is ["sabana" | "tipif" | "ventas", CurrentUpload, string, string] => Boolean(x[1]));
      if (dated.length) {
        const res = await db.batch(
          dated.map(([, u, table, col]) =>
            db
              .prepare(
                `SELECT MAX(CASE WHEN substr(${col}, 1, 7) = ?1 THEN substr(${col}, 1, 10) END) AS hasta,
                        SUM(CASE WHEN ${col} GLOB '20[0-9][0-9]-[0-9][0-9]*' AND substr(${col}, 1, 7) <> ?1 THEN 1 ELSE 0 END) AS fuera,
                        GROUP_CONCAT(DISTINCT CASE WHEN ${col} GLOB '20[0-9][0-9]-[0-9][0-9]*' AND substr(${col}, 1, 7) <> ?1 THEN substr(${col}, 1, 7) END) AS meses
                   FROM ${table} WHERE upload_id = ?2`,
              )
              .bind(month, u.id),
          ),
        );
        let hasta: string | null = null;
        res.forEach((r, i) => {
          const row = r.results[0] as { hasta: string | null; fuera: number | null; meses: string | null } | undefined;
          if (row?.hasta && (!hasta || row.hasta > hasta)) hasta = row.hasta;
          // La sábana trae ventas de meses anteriores a propósito (cosecha): no es un error.
          if (n(row?.fuera) > 0 && dated[i]![0] !== "sabana") out.fechas.fuera.push({ kind: dated[i]![0], filas: n(row!.fuera), meses: (row!.meses ?? "").split(",").filter(Boolean).sort() });
        });
        const h = hasta as string | null;
        out.fechas.hasta = rango && h && h > rango.d2 ? rango.d2 : h;
      }
    }

  })();

  /* ---------- ventas (sábana del banco) ---------- */
  const ventasP = (async () => {
    if (sabana) {
      const id = sabana.id;
      const [totals, estatus, ejecutivos, motivos, dias, procesos, mensual] = await db.batch([
        db.prepare(`SELECT status_class AS c, COUNT(*) AS n, COALESCE(SUM(amount), 0) AS m FROM bank_sales WHERE upload_id = ?${fs("")} GROUP BY status_class`).bind(id, ...fb),
        db
          .prepare(
            `SELECT COALESCE(NULLIF(TRIM(status_raw), ''), '(sin estatus)') AS label, status_class AS c, COUNT(*) AS n, COALESCE(SUM(amount), 0) AS m FROM bank_sales WHERE upload_id = ?${fs("")} GROUP BY 1, 2 ORDER BY n DESC LIMIT 25`,
          )
          .bind(id, ...fb),
        db
          .prepare(
            `SELECT ${agentLabel("executive")} AS agent, COUNT(*) AS ventas,
                    SUM(status_class = 'aprobado') AS aprobadas, SUM(status_class = 'rechazado') AS rechazadas, SUM(status_class = 'no_desembolsado') AS no_desemb,
                    COALESCE(SUM(amount), 0) AS monto, COALESCE(SUM(CASE WHEN status_class = 'aprobado' THEN amount END), 0) AS monto_aprobado
               FROM bank_sales WHERE upload_id = ?${fs("")} GROUP BY 1 ORDER BY ventas DESC`,
          )
          .bind(id, ...fb),
        db
          .prepare(
            `SELECT COALESCE(NULLIF(TRIM(reason), ''), 'Sin motivo especificado') AS label, COUNT(*) AS n, COALESCE(SUM(amount), 0) AS m FROM bank_sales WHERE upload_id = ?${fs("")} AND status_class = 'rechazado' GROUP BY 1 ORDER BY n DESC LIMIT 15`,
          )
          .bind(id, ...fb),
        db
          .prepare(
            `SELECT sale_date AS d, COUNT(*) AS ventas, SUM(status_class = 'aprobado') AS aprobadas, COALESCE(SUM(amount), 0) AS monto,
                    COALESCE(SUM(CASE WHEN status_class = 'aprobado' THEN amount END), 0) AS monto_aprobado FROM bank_sales WHERE upload_id = ?${fs("")} AND sale_date IS NOT NULL GROUP BY sale_date ORDER BY sale_date`,
          )
          .bind(id, ...fb),
        db.prepare(`SELECT process AS label, COUNT(*) AS n FROM bank_sales WHERE upload_id = ?${fs("")} AND process IS NOT NULL GROUP BY process ORDER BY n DESC`).bind(id, ...fb),
        db
          .prepare(
            `SELECT u.month AS month, COUNT(*) AS ventas, SUM(b.status_class = 'aprobado') AS aprobadas,
                    SUM(b.status_class = 'rechazado') AS rechazadas, SUM(b.status_class = 'no_desembolsado') AS no_desemb, SUM(b.status_class = 'en_proceso') AS en_proceso,
                    COALESCE(SUM(b.amount), 0) AS monto, COALESCE(SUM(CASE WHEN b.status_class = 'aprobado' THEN b.amount END), 0) AS monto_aprobado
               FROM bank_sales b JOIN uploads u ON u.id = b.upload_id
              WHERE u.campaign = ? AND u.is_current = 1 AND u.kind = 'sabana'${fa("b.executive")}${porMesEnRango("b.sale_date")}
              GROUP BY u.month ORDER BY u.month`,
          )
          .bind(campaign, ...fb),
      ]);
      const byClass = Object.fromEntries((totals!.results as { c: string; n: number }[]).map((r) => [r.c, n(r.n)]));
      const montoByClass = Object.fromEntries((totals!.results as { c: string; m: number }[]).map((r) => [r.c, n(r.m)]));
      const aprobadas = byClass.aprobado ?? 0;
      const rechazadas = byClass.rechazado ?? 0;
      const noDesembolsadas = byClass.no_desembolsado ?? 0;
      const enProceso = byClass.en_proceso ?? 0;
      const total = aprobadas + rechazadas + noDesembolsadas + enProceso;
      out.ventas = {
        total,
        aprobadas,
        rechazadas,
        noDesembolsadas,
        enProceso,
        aprobacion: pct(aprobadas, aprobadas + rechazadas + noDesembolsadas),
        monto: {
          total: Object.values(montoByClass).reduce((x, y) => x + y, 0),
          aprobado: montoByClass.aprobado ?? 0,
          rechazado: montoByClass.rechazado ?? 0,
          noDesembolsado: montoByClass.no_desembolsado ?? 0,
          enProceso: montoByClass.en_proceso ?? 0,
        },
        porEstatus: (estatus!.results as { label: string; c: string; n: number; m: number }[]).map((r) => ({ label: r.label, class: r.c, value: n(r.n), monto: n(r.m) })),
        porEjecutivo: (ejecutivos!.results as { agent: string; ventas: number; aprobadas: number; rechazadas: number; no_desemb: number; monto: number; monto_aprobado: number }[]).map((r) => ({
          agent: r.agent,
          ventas: n(r.ventas),
          aprobadas: n(r.aprobadas),
          rechazadas: n(r.rechazadas),
          noDesembolsadas: n(r.no_desemb),
          aprobacion: pct(n(r.aprobadas), n(r.aprobadas) + n(r.rechazadas) + n(r.no_desemb)),
          monto: n(r.monto),
          montoAprobado: n(r.monto_aprobado),
        })),
        rechazoPorMotivo: (motivos!.results as { label: string; n: number; m: number }[]).map((r) => ({ label: r.label, value: n(r.n), monto: n(r.m) })),
        porDia: (dias!.results as { d: string; ventas: number; aprobadas: number; monto: number; monto_aprobado: number }[]).map((r) => ({
          date: r.d,
          ventas: n(r.ventas),
          aprobadas: n(r.aprobadas),
          monto: n(r.monto),
          montoAprobado: n(r.monto_aprobado),
        })),
        porProceso: (procesos!.results as { label: string; n: number }[]).map((r) => ({ label: r.label, value: n(r.n) })),
        mensual: (mensual!.results as { month: string; ventas: number; aprobadas: number; rechazadas: number; no_desemb: number; en_proceso: number; monto: number; monto_aprobado: number }[]).map((r) => ({
          month: r.month,
          ventas: n(r.ventas),
          aprobadas: n(r.aprobadas),
          rechazadas: n(r.rechazadas),
          noDesembolsadas: n(r.no_desemb),
          enProceso: n(r.en_proceso),
          aprobacion: pct(n(r.aprobadas), n(r.aprobadas) + n(r.rechazadas) + n(r.no_desemb)),
          monto: n(r.monto),
          montoAprobado: n(r.monto_aprobado),
        })),
        cosecha: { total: 0, monto: 0, porMes: [] },
        procesos: { actual: [], cosecha: [] },
        requisitos: null,
        pcbm: null,
      };
      // Cosecha: ventas de meses anteriores que vienen en la sábana de este mes.
      if (month) {
        const [cos, proc, req, pcbm] = await db.batch([
          db
            .prepare(
              `SELECT substr(sale_date, 1, 7) AS m, COUNT(*) AS n, COALESCE(SUM(amount), 0) AS monto FROM bank_sales
                WHERE upload_id = ?${fs("")} AND sale_date IS NOT NULL AND substr(sale_date, 1, 7) < ? GROUP BY 1 ORDER BY 1 DESC`,
            )
            .bind(id, ...fb, month),
          /* En qué proceso va cada venta: del mes (fecha del mes o sin fecha) y de la cosecha (fecha de un mes
             anterior), por separado. Evaluadas = aprobadas + rechazadas + no desembolsadas; pendientes = las que siguen en proceso. */
          db
            .prepare(
              `SELECT CASE WHEN sale_date IS NULL OR substr(sale_date, 1, 7) >= ? THEN 'actual' ELSE 'cosecha' END AS origen,
                      COALESCE(NULLIF(TRIM(process), ''), 'Sin proceso') AS proceso, COUNT(*) AS n,
                      SUM(status_class = 'aprobado') AS ap, SUM(status_class = 'rechazado') AS re, SUM(status_class = 'no_desembolsado') AS nd, SUM(status_class = 'en_proceso') AS ep,
                      COALESCE(SUM(amount), 0) AS m, COALESCE(SUM(CASE WHEN status_class = 'aprobado' THEN amount END), 0) AS ma
                 FROM bank_sales WHERE upload_id = ?${fs("")} GROUP BY 1, 2 ORDER BY n DESC`,
            )
            .bind(month, id, ...fb),
          /* Pendientes por requisito: solo la subetapa "PENDIENTE POR REQUISITO" exacta, como la tabla dinámica de
             la sábana ("PENDIENTE POR REQUISITO/VENCIDOS", extrarrequisito y creación de empresas son otras subetapas).
             A quién y qué documento se le está pidiendo (columnas de la sábana TDC:
             "PENDIENTE POR REQUISITO" y "DOCUMENTACION"; la observación de extrarrequisito como detalle). */
          db
            .prepare(
              `SELECT niu, sale_date AS fecha, ${agentLabel("executive")} AS agente, COALESCE(NULLIF(TRIM(status_raw), ''), '(sin estatus)') AS estatus,
                      NULLIF(TRIM(json_extract(extra, '$.NOMBRE')), '') AS nombre,
                      NULLIF(TRIM(json_extract(extra, '$."PENDIENTE POR REQUISITO"')), '') AS pend,
                      NULLIF(TRIM(json_extract(extra, '$.DOCUMENTACION')), '') AS doc,
                      NULLIF(TRIM(json_extract(extra, '$."MOTIVO DEVOLUCION/OBSERVACIONES EXTRARREQUISITO/COMENTARIO GENERAL"')), '') AS obs,
                      CASE WHEN sale_date IS NULL OR substr(sale_date, 1, 7) >= ? THEN 'mes' ELSE 'cosecha' END AS origen,
                      days_in_process AS dias_banco,
                      /* Desde cuándo está pendiente: la primera sábana cargada (también versiones anteriores) donde esa
                         misma venta (NIU y fecha) ya venía pendiente por requisito. Fecha de esa sábana = el día en que
                         se cargó, o el último día de su mes si se cargó después (cargas atrasadas); nunca antes de la venta. */
                      (SELECT MIN(MIN(date(u2.created_at / 1000 - 21600, 'unixepoch'), date(u2.month || '-01', '+1 month', '-1 day')))
                         FROM bank_sales p JOIN uploads u2 ON u2.id = p.upload_id
                        WHERE p.niu = bank_sales.niu AND COALESCE(p.sale_date, '') = COALESCE(bank_sales.sale_date, '')
                          AND u2.campaign = ? AND u2.kind = 'sabana' AND u2.status IN ('vigente', 'reemplazada')
                          AND ${PEND_REQ("p.status_raw")}) AS visto
                 FROM bank_sales WHERE upload_id = ?${fs("")} AND ${PEND_REQ("status_raw")}
                ORDER BY sale_date, niu LIMIT 3000`,
            )
            .bind(month, campaign, id, ...fb),
          /* Evaluación PCBM (TDC): evaluada = ya pasó por PCBM, o sea, ya tiene resolución: aprobada (entregada, en
             distribución, sin embozo, devolución…) o rechazada. Lo demás (en PCBM sin resolver, apoyo Talk) está
             pendiente. Por etapa primaria y subetapa, como la tabla dinámica de la sábana. */
          db
            .prepare(
              `SELECT CASE WHEN sale_date IS NULL OR substr(sale_date, 1, 7) >= ? THEN 'mes' ELSE 'cosecha' END AS origen,
                      COALESCE(NULLIF(TRIM(json_extract(extra, '$."ETAPA PRIMARIA"')), ''), '(sin etapa)') AS etapa,
                      COALESCE(NULLIF(TRIM(status_raw), ''), '(sin estatus)') AS estatus, status_class AS clase, COUNT(*) AS n
                 FROM bank_sales WHERE upload_id = ?${fs("")} GROUP BY 1, 2, 3, 4`,
            )
            .bind(month, id, ...fb),
        ]);
        type Pcbm = { origen: "mes" | "cosecha"; etapa: string; estatus: string; clase: SaleClass; n: number };
        const pcbmRows = pcbm!.results as Pcbm[];
        const filaPcbm = (rs: Pcbm[]) => {
          const de = (c: SaleClass) => rs.filter((r) => r.clase === c).reduce((t, r) => t + n(r.n), 0);
          const aprobadas = de("aprobado");
          const rechazadas = de("rechazado");
          const noDesembolsadas = de("no_desembolsado");
          const evaluadas = aprobadas + rechazadas + noDesembolsadas;
          return {
            ventas: rs.reduce((t, r) => t + n(r.n), 0),
            evaluadas,
            aprobadas,
            rechazadas,
            noDesembolsadas,
            pendientes: de("en_proceso"),
            aprobacion: pct(aprobadas, evaluadas),
            rechazo: pct(rechazadas, evaluadas),
            noDesembolso: pct(noDesembolsadas, evaluadas),
          };
        };
        // Todas las campañas (el desglose por estatus); la etapa primaria solo la trae la sábana de TC.
        if (pcbmRows.length) {
          const etapas = new Map<string, { etapa: string; estatus: string; clase: SaleClass; ventas: number; cosecha: number }>();
          for (const r of pcbmRows) {
            const k = `${r.etapa}|${r.estatus}|${r.clase}`;
            const e = etapas.get(k) ?? { etapa: r.etapa, estatus: r.estatus, clase: r.clase, ventas: 0, cosecha: 0 };
            e.ventas += n(r.n);
            if (r.origen === "cosecha") e.cosecha += n(r.n);
            etapas.set(k, e);
          }
          out.ventas.pcbm = {
            mes: filaPcbm(pcbmRows.filter((r) => r.origen === "mes")),
            cosecha: filaPcbm(pcbmRows.filter((r) => r.origen === "cosecha")),
            total: filaPcbm(pcbmRows),
            // Ordenadas como la tabla dinámica: por etapa ("1ENTREGADA", "2EN DISTRIBUCION"…) y, dentro, de mayor a menor.
            etapas: [...etapas.values()].sort(
              (x, y) => Number(x.etapa === "(sin etapa)") - Number(y.etapa === "(sin etapa)") || x.etapa.localeCompare(y.etapa, "es", { numeric: true }) || y.ventas - x.ventas,
            ),
          };
        }
        type Req = {
          niu: string;
          fecha: string | null;
          agente: string;
          estatus: string;
          nombre: string | null;
          pend: string | null;
          doc: string | null;
          obs: string | null;
          origen: "mes" | "cosecha";
          dias_banco: number | null;
          visto: string | null;
        };
        const pendientes = (req!.results as Req[]).map((r) => ({
          niu: r.niu,
          nombre: r.nombre,
          fecha: r.fecha,
          agente: r.agente,
          estatus: r.estatus,
          documento: r.pend ?? r.doc,
          documentacion: r.doc,
          observacion: r.obs,
          origen: r.origen,
          pendienteDesde: r.visto && r.fecha && /^\d{4}-\d{2}-\d{2}/.test(r.fecha) && r.fecha.slice(0, 10) > r.visto ? r.fecha.slice(0, 10) : r.visto,
          diasBanco: r.dias_banco === null || r.dias_banco === undefined ? null : n(r.dias_banco),
        }));
        const unificado = agruparDocumentos(pendientes.map((x) => x.documento));
        out.ventas.requisitos = pendientes.length
          ? { clientes: pendientes.map((x, i) => ({ ...x, grupo: unificado.grupos[i]! })), porDocumento: unificado.porDocumento }
          : null;
        const prevRows = cos!.results as { m: string; n: number; monto: number }[];
        out.ventas.cosecha = {
          total: prevRows.reduce((t, r) => t + n(r.n), 0),
          monto: prevRows.reduce((t, r) => t + n(r.monto), 0),
          porMes: prevRows.map((r) => ({ month: r.m, ventas: n(r.n), monto: n(r.monto) })),
        };
        type P = { origen: string; proceso: string; n: number; ap: number; re: number; nd: number; ep: number; m: number; ma: number };
        const filas = (origen: string) =>
          (proc!.results as P[])
            .filter((r) => r.origen === origen)
            .map((r) => ({ proceso: r.proceso, ventas: n(r.n), aprobadas: n(r.ap), rechazadas: n(r.re), noDesembolsadas: n(r.nd), pendientes: n(r.ep), monto: n(r.m), montoAprobado: n(r.ma) }));
        out.ventas.procesos = { actual: filas("actual"), cosecha: filas("cosecha") };
      }
    }

  })();

  /* ---------- base ---------- */
  const baseIds = bases.map((b) => b.id);
  let baseUnicos = 0;
  // Clientes de la base del mes con venta en la sábana (cruce por NIU): para la penetración.
  let ventasEnBase: number | null = null;
  const baseP = (async () => {
    if (baseIds.length) {
      const inIds = placeholders(baseIds.length);
      const stmts = [
        db.prepare(`SELECT dataset, COUNT(*) AS registros, COUNT(DISTINCT niu) AS unicos FROM base_records WHERE upload_id IN (${inIds}) GROUP BY dataset`).bind(...baseIds),
        db.prepare(`SELECT COUNT(DISTINCT niu) AS n FROM base_records WHERE upload_id IN (${inIds})`).bind(...baseIds),
        db
          .prepare(
            `SELECT u.month AS month, u.dataset AS dataset, COUNT(DISTINCT b.niu) AS unicos
               FROM base_records b JOIN uploads u ON u.id = b.upload_id
              WHERE u.campaign = ? AND u.is_current = 1 AND u.kind = 'base' GROUP BY u.month, u.dataset ORDER BY u.month`,
          )
          .bind(campaign),
      ];
      // Perfiles de la base cruzados con la sábana del mismo mes.
      stmts.push(
        sabana
          ? db
              .prepare(
                `WITH b AS (SELECT niu, MAX(COALESCE(NULLIF(TRIM(profile), ''), 'N/D')) AS profile FROM base_records WHERE upload_id IN (${inIds}) GROUP BY niu),
                      s AS (SELECT niu, MAX(status_class = 'aprobado') AS apr, MAX(status_class = 'rechazado') AS rech FROM bank_sales WHERE upload_id = ?${fs("")} GROUP BY niu)
                 SELECT b.profile AS profile, COUNT(*) AS base, COUNT(s.niu) AS con_venta, SUM(COALESCE(s.apr, 0)) AS aprobadas, SUM(COALESCE(s.rech, 0)) AS rechazadas
                   FROM b LEFT JOIN s ON s.niu = b.niu GROUP BY b.profile ORDER BY base DESC LIMIT 30`,
              )
              .bind(...baseIds, sabana.id, ...fb)
          : db
              .prepare(
                `SELECT profile, COUNT(*) AS base, 0 AS con_venta, 0 AS aprobadas, 0 AS rechazadas
                   FROM (SELECT niu, MAX(COALESCE(NULLIF(TRIM(profile), ''), 'N/D')) AS profile FROM base_records WHERE upload_id IN (${inIds}) GROUP BY niu)
                  GROUP BY profile ORDER BY base DESC LIMIT 30`,
              )
              .bind(...baseIds),
      );
      // Cada carga de base (original y adicionales, en orden de llegada): clientes nuevos que aportó
      // (los que no venían en una base anterior del mes) y cómo se trabajaron esos clientes.
      const ordered = [...bases].sort((x, y) => x.is_addition - y.is_addition || x.created_at - y.created_at);
      const effSql = efectivoSql.replace(/call_class/g, "c.call_class");
      const perUpload = ordered.map((u, i) => {
        const earlier = ordered.slice(0, i).map((x) => x.id);
        const notEarlier = earlier.length ? ` AND niu NOT IN (SELECT niu FROM base_records WHERE upload_id IN (${placeholders(earlier.length)}))` : "";
        return db
          .prepare(
            `WITH b AS (SELECT DISTINCT niu FROM base_records WHERE upload_id = ?${notEarlier})
             SELECT (SELECT COUNT(*) FROM base_records WHERE upload_id = ?) AS registros,
                    (SELECT COUNT(DISTINCT niu) FROM base_records WHERE upload_id = ?) AS unicos,
                    (SELECT COUNT(*) FROM b) AS nuevos,
                    (SELECT COUNT(DISTINCT c.niu) FROM calls c JOIN b ON b.niu = c.niu WHERE c.upload_id = ?${fl("c.")}) AS llamados,
                    (SELECT COUNT(*) FROM calls c JOIN b ON b.niu = c.niu WHERE c.upload_id = ?${fl("c.")}) AS toques,
                    (SELECT COUNT(DISTINCT c.niu) FROM calls c JOIN b ON b.niu = c.niu WHERE c.upload_id = ?${fl("c.")} AND ${effSql}) AS contactados,
                    (SELECT COUNT(DISTINCT s.niu) FROM bank_sales s JOIN b ON b.niu = s.niu WHERE s.upload_id = ?${fs("s.")}) AS ventas,
                    (SELECT COUNT(DISTINCT s.niu) FROM bank_sales s JOIN b ON b.niu = s.niu WHERE s.upload_id = ?${fs("s.")} AND s.status_class = 'aprobado') AS aprobadas`,
          )
          .bind(u.id, ...earlier, u.id, u.id, tipif?.id ?? null, ...fb, tipif?.id ?? null, ...fb, tipif?.id ?? null, ...fb, sabana?.id ?? null, ...fb, sabana?.id ?? null, ...fb);
      });
      // Cuadre con la tipificación: toda llamada del archivo es a un cliente de alguna base del mes, a un cliente que
      // no viene en ninguna base, o sin NIU. Así la suma de los toques de cada base más lo de fuera da el total.
      if (tipif)
        stmts.push(
          db
            .prepare(
              `WITH b AS (SELECT DISTINCT niu FROM base_records WHERE upload_id IN (SELECT value FROM json_each(?)))
               SELECT COUNT(*) AS llamadas,
                      SUM(COALESCE(c.niu, '') = '') AS sin_niu,
                      SUM(COALESCE(c.niu, '') <> '' AND b.niu IS NULL) AS fuera,
                      COUNT(DISTINCT CASE WHEN COALESCE(c.niu, '') <> '' AND b.niu IS NULL THEN c.niu END) AS clientes_fuera
                 FROM calls c LEFT JOIN b ON b.niu = c.niu WHERE c.upload_id = ?${fl("c.")}`,
            )
            .bind(JSON.stringify(baseIds), tipif.id, ...fb),
        );
      // Penetración: clientes de la base (original y adicionales) con venta en la sábana del mes, por NIU.
      stmts.splice(
        4,
        0,
        sabana
          ? db
              .prepare(`SELECT COUNT(DISTINCT s.niu) AS n FROM bank_sales s WHERE s.upload_id = ?${fs("s.")} AND s.niu IN (SELECT niu FROM base_records WHERE upload_id IN (${inIds}))`)
              .bind(sabana.id, ...fb, ...baseIds)
          : db.prepare("SELECT NULL AS n"),
      );
      const [porArchivo, unicos, historial, perfiles, enBase, ...resto] = await db.batch([...stmts, ...perUpload]);
      const enBaseN = (enBase!.results[0] as { n: number | null } | undefined)?.n;
      ventasEnBase = enBaseN === null || enBaseN === undefined ? null : n(enBaseN);
      const cuadre = tipif ? (resto.shift()!.results[0] as Record<string, number> | undefined) : undefined;
      const cargas = resto;
      baseUnicos = n((unicos!.results[0] as { n: number } | undefined)?.n);
      const porCarga = ordered.map((u, i) => {
        const r = cargas[i]!.results[0] as Record<string, number>;
        const nuevos = n(r.nuevos);
        return {
          uploadId: u.id,
          dataset: u.dataset,
          adicional: Boolean(u.is_addition),
          nombre: u.label,
          llegada: u.created_at,
          registros: n(r.registros),
          unicos: n(r.unicos),
          nuevos,
          repetidos: n(r.unicos) - nuevos,
          llamados: n(r.llamados),
          recorrido: pct(n(r.llamados), nuevos),
          toques: n(r.toques),
          promedioToques: n(r.llamados) ? n(r.toques) / n(r.llamados) : 0,
          contactados: n(r.contactados),
          ventas: n(r.ventas),
          aprobadas: n(r.aprobadas),
          penetracion: pct(n(r.ventas), nuevos),
        };
      });
      const recorridos = porCarga.reduce((t, c) => t + c.llamados, 0);
      const toques = porCarga.reduce((t, c) => t + c.toques, 0);
      out.base = {
        total: baseUnicos,
        ventasEnBase,
        porCarga,
        recorridos: tipif ? { clientes: recorridos, recorrido: pct(recorridos, baseUnicos), toques, promedioToques: recorridos ? toques / recorridos : 0 } : null,
        cuadre: cuadre
          ? { llamadas: n(cuadre.llamadas), aBase: toques, fueraDeBase: n(cuadre.fuera), clientesFuera: n(cuadre.clientes_fuera), sinNiu: n(cuadre.sin_niu) }
          : null,
        porArchivo: (porArchivo!.results as { dataset: string; registros: number; unicos: number }[]).map((r) => ({ dataset: r.dataset, registros: n(r.registros), unicos: n(r.unicos) })),
        historial: (historial!.results as { month: string; dataset: string; unicos: number }[]).map((r) => ({ month: r.month, dataset: r.dataset, unicos: n(r.unicos) })),
        porPerfil: (perfiles!.results as { profile: string; base: number; con_venta: number; aprobadas: number; rechazadas: number }[]).map((r) => ({
          profile: r.profile,
          base: n(r.base),
          conVenta: n(r.con_venta),
          aprobadas: n(r.aprobadas),
          rechazadas: n(r.rechazadas),
          penetracion: pct(n(r.con_venta), n(r.base)),
        })),
      };
    }

  })();

  /* ---------- llamadas (VICI) ---------- */
  const llamadasP = (async () => {
    if (tipif) {
      const id = tipif.id;
      const [clases, unicos, agentes, tipologias, dias, intentos, estructura, ventasSeq] = await db.batch([
        db.prepare(`SELECT call_class AS label, COUNT(*) AS n FROM calls WHERE upload_id = ?${fl("")} GROUP BY call_class ORDER BY n DESC`).bind(id, ...fb),
        db.prepare(`SELECT COUNT(DISTINCT niu) AS n, COUNT(DISTINCT CASE WHEN call_class = 'venta' THEN niu END) AS ventas FROM calls WHERE upload_id = ?${fl("")} AND niu <> ''`).bind(id, ...fb),
        db
          .prepare(
            `SELECT ${agentLabel("agent")} AS agent, COUNT(*) AS llamadas, COUNT(DISTINCT NULLIF(niu, '')) AS registros,
                    SUM(${efectivoSql}) AS efectivos, SUM(call_class = 'venta') AS ventas, SUM(call_class = 'no_contacto') AS no_contacto
               FROM calls WHERE upload_id = ?${fl("")} GROUP BY 1 ORDER BY llamadas DESC`,
          )
          .bind(id, ...fb),
        db
          .prepare(
            `SELECT COALESCE(NULLIF(TRIM(tipologia), ''), 'Sin Tipificar') AS label, call_class AS c, COUNT(*) AS n FROM calls WHERE upload_id = ?${fl("")} GROUP BY 1, 2 ORDER BY n DESC LIMIT 20`,
          )
          .bind(id, ...fb),
        db
          .prepare(
            `SELECT substr(called_at, 1, 10) AS d, COUNT(*) AS llamadas, SUM(${efectivoSql}) AS efectivos
               FROM calls WHERE upload_id = ?${fl("")} AND called_at IS NOT NULL GROUP BY 1 ORDER BY 1`,
          )
          .bind(id, ...fb),
        db
          .prepare(
            `SELECT CASE WHEN k >= 6 THEN '6+' ELSE CAST(k AS TEXT) END AS intentos, COUNT(*) AS clientes
               FROM (SELECT niu, COUNT(*) AS k FROM calls WHERE upload_id = ?${fl("")} AND niu <> '' GROUP BY niu)
              GROUP BY 1 ORDER BY MIN(k)`,
          )
          .bind(id, ...fb),
        db
          .prepare(
            `SELECT SUM(seq = 1) AS primeros, SUM(seq > 1) AS seguimientos
               FROM (SELECT ROW_NUMBER() OVER (PARTITION BY niu ORDER BY called_at) AS seq FROM calls WHERE upload_id = ?${fl("")} AND niu <> '')`,
          )
          .bind(id, ...fb),
        db
          .prepare(
            `SELECT SUM(first_sale = 1) AS primero, SUM(first_sale > 1) AS rellamado FROM (
               SELECT niu, MIN(seq) AS first_sale FROM (
                 SELECT niu, call_class, ROW_NUMBER() OVER (PARTITION BY niu ORDER BY called_at) AS seq FROM calls WHERE upload_id = ?${fl("")} AND niu <> ''
               ) WHERE call_class = 'venta' GROUP BY niu)`,
          )
          .bind(id, ...fb),
      ]);
      const clasesRows = (clases!.results as { label: string; n: number }[]).map((r) => ({ label: r.label, value: n(r.n) }));
      const total = clasesRows.reduce((s, r) => s + r.value, 0);
      const efectivos = clasesRows
        .filter((r) => r.label === "venta" || r.label === "negativo" || (rule === "con_no_efectivo" && r.label === "no_efectivo"))
        .reduce((s, r) => s + r.value, 0);
      const u = unicos!.results[0] as { n: number; ventas: number } | undefined;
      const est = estructura!.results[0] as { primeros: number; seguimientos: number } | undefined;
      const vs = ventasSeq!.results[0] as { primero: number; rellamado: number } | undefined;
      out.llamadas = {
        total,
        registros: n(u?.n),
        efectivos,
        contactabilidad: pct(efectivos, total),
        reglaContacto: rule,
        porClase: clasesRows,
        porAgente: (agentes!.results as { agent: string; llamadas: number; registros: number; efectivos: number; ventas: number; no_contacto: number }[]).map((r) => ({
          agent: r.agent,
          llamadas: n(r.llamadas),
          registros: n(r.registros),
          efectivos: n(r.efectivos),
          ventas: n(r.ventas),
          noContacto: n(r.no_contacto),
          contactabilidad: pct(n(r.efectivos), n(r.llamadas)),
        })),
        tipologias: (tipologias!.results as { label: string; c: string; n: number }[]).map((r) => ({ label: r.label, class: r.c, value: n(r.n) })),
        porDia: (dias!.results as { d: string; llamadas: number; efectivos: number }[]).map((r) => ({ date: r.d, llamadas: n(r.llamadas), efectivos: n(r.efectivos) })),
        intentos: (intentos!.results as { intentos: string; clientes: number }[]).map((r) => ({ intentos: r.intentos, clientes: n(r.clientes) })),
        primerContacto: n(est?.primeros),
        seguimiento: n(est?.seguimientos),
        ventasPrimerIntento: n(vs?.primero),
        ventasRellamado: n(vs?.rellamado),
        ventasUnicas: n(u?.ventas),
        // Se completa cuando termina la base (las secciones van en paralelo).
        penetracion: null,
      };
    }

  })();

  /* ---------- ventas capturadas en el CRM ---------- */
  const crmP = (async () => {
    if (crm) {
      const [tot, agentes, dias, match] = await db.batch([
        db.prepare(`SELECT COUNT(*) AS n FROM crm_sales WHERE upload_id = ?${fc("")}`).bind(crm.id, ...fb),
        db.prepare(`SELECT ${agentLabel("agent")} AS label, COUNT(*) AS n FROM crm_sales WHERE upload_id = ?${fc("")} GROUP BY 1 ORDER BY n DESC`).bind(crm.id, ...fb),
        db.prepare(`SELECT substr(entered_at, 1, 10) AS d, COUNT(*) AS n FROM crm_sales WHERE upload_id = ?${fc("")} AND entered_at IS NOT NULL GROUP BY 1 ORDER BY 1`).bind(crm.id, ...fb),
        sabana
          ? db.prepare(`SELECT COUNT(DISTINCT c.niu) AS n FROM crm_sales c WHERE c.upload_id = ?${fc("c.")} AND EXISTS (SELECT 1 FROM bank_sales b WHERE b.upload_id = ? AND b.niu = c.niu)`).bind(crm.id, ...fb, sabana.id)
          : db.prepare("SELECT NULL AS n"),
      ]);
      out.crm = {
        total: n((tot!.results[0] as { n: number } | undefined)?.n),
        conEstatusBanco: sabana ? n((match!.results[0] as { n: number } | undefined)?.n) : null,
        porAgente: (agentes!.results as { label: string; n: number }[]).map((r): Count => ({ label: r.label, value: n(r.n) })),
        porDia: (dias!.results as { d: string; n: number }[]).map((r) => ({ date: r.d, ventas: n(r.n) })),
      };
    }

  })();

  /* ---------- agentes del mes (para el filtro) ---------- */
  const agentesP = (async () => {
    const sources: [string | undefined, string, string][] = [
      [sabana?.id, "bank_sales", "executive"],
      [tipif?.id, "calls", "agent"],
      [crm?.id, "crm_sales", "agent"],
    ];
    const withAgents = sources.filter((x): x is [string, string, string] => Boolean(x[0]));
    if (withAgents.length) {
      const { results } = await db
        .prepare(withAgents.map(([, t, col]) => `SELECT DISTINCT ${agentLabel(col)} AS a FROM ${t} WHERE upload_id = ?`).join(" UNION ") + " ORDER BY a")
        .bind(...withAgents.map(([id]) => id))
        .all<{ a: string }>();
      out.agentes = results.map((r) => r.a).sort((x, y) => x.localeCompare(y, "es"));
    }
  })();

  /* ---------- cumplimiento ---------- */
  const cumplimientoP = (async () => {
    if (month) {
      const c = out.cumplimiento;
      // Meta del mes; si aún no hay, la configuración del último mes con meta sirve de punto de partida.
      const goal = goalRows.find((g) => g.month === month) ?? null;
      const anterior = goalRows.filter((g) => g.month < month).sort((x, y) => y.month.localeCompare(x.month))[0];
      const base: GoalRow | null = goal ?? (anterior ? { sales_goal: null, agents: null, counted_statuses: anterior.counted_statuses, work_days: anterior.work_days, holidays: "[]" } : null);
      const savedStatuses = parseList(base?.counted_statuses);
      c.config = {
        estatus: [],
        estatusPorDefecto: savedStatuses === null,
        diasSemana: parseDays(base?.work_days),
        feriados: (parseList(goal?.holidays) ?? []).filter((d) => d.startsWith(month)),
      };
      c.meta = goal ? n(goal.sales_goal) : null;
      c.agentes = goal?.agents ?? null;
      c.metaPorAgente = c.meta !== null && c.agentes ? c.meta / c.agentes : null;
      // Con filtro por agente, la meta que se mide es la individual.
      if (agente) c.meta = c.metaPorAgente;

      const habiles = businessDays(month, c.config.diasSemana, c.config.feriados);
      c.diasDelMes = habiles.length;

      if (sabana) {
        const label = "COALESCE(NULLIF(TRIM(status_raw), ''), '(sin estatus)')";
        const { results: estatus } = await db
          .prepare(`SELECT ${label} AS label, COUNT(*) AS n, COALESCE(SUM(amount), 0) AS monto FROM bank_sales WHERE upload_id = ?${fs("")} GROUP BY 1 ORDER BY n DESC`)
          .bind(sabana.id, ...fb)
          .all<{ label: string; n: number; monto: number }>();
        const cuenta = (l: string) => (savedStatuses ? savedStatuses.includes(l) : countsForGoal(campaign as CampaignCode, l));
        c.estatusDisponibles = estatus.map((r) => ({ label: r.label, value: n(r.n), monto: n(r.monto), cuenta: cuenta(r.label) }));
        // Los guardados se respetan aunque este mes no aparezcan; los de la regla, solo los presentes.
        c.config.estatus = savedStatuses ?? c.estatusDisponibles.filter((e) => e.cuenta).map((e) => e.label);
        const counted = c.config.estatus;
        // La lista de estatus viaja como un solo JSON: D1 acepta máximo 100 valores por consulta.
        const inList = counted.length ? `${label} IN (SELECT value FROM json_each(?))` : "0";
        // CDC y Extra se miden en dólares: se suma el monto de la sábana en vez de contar ventas.
        const measure = c.unidad === "monto" ? "COALESCE(amount, 0)" : "1";
        /* Cosecha: la sábana del mes trae también ventas de meses anteriores. Cuenta para la meta de este mes
           lo que el banco entregó, aplicó o activó y que NO contó ya en la sábana de un mes anterior
           (misma venta = mismo NIU y misma fecha de venta). k: 0 no cuenta, 1 cuenta, 2 ya contó antes.
           Se busca con IN (subconsulta) y no con EXISTS: así SQLite arma un índice temporal y no recorre todas las
           ventas de los meses anteriores por cada venta (con sábanas consolidadas de varios meses tardaba demasiado). */
        const prevLabel = "COALESCE(NULLIF(TRIM(p.status_raw), ''), '(sin estatus)')";
        const prevCte = counted.length
          ? `prev AS (SELECT DISTINCT p.niu, COALESCE(p.sale_date, '') AS d FROM bank_sales p
               WHERE p.upload_id IN (SELECT id FROM uploads WHERE campaign = ? AND kind = 'sabana' AND is_current = 1 AND month < ?)
                 AND ${prevLabel} IN (SELECT value FROM json_each(?)))`
          : "prev AS (SELECT NULL AS niu, NULL AS d WHERE 0)";
        const lista = JSON.stringify(counted);
        const prevBinds = counted.length ? [campaign, month, lista] : [];
        const rowsCte = `s AS (SELECT ${agentLabel("executive")} AS agent, ${measure} AS m, status_class, sale_date,
               CASE WHEN ${inList} THEN (CASE WHEN (bank_sales.niu || '|' || COALESCE(bank_sales.sale_date, '')) IN (SELECT niu || '|' || d FROM prev) THEN 2 ELSE 1 END) ELSE 0 END AS k
             FROM bank_sales WHERE upload_id = ?${fs("")})`;
        const cteBinds = [...prevBinds, ...(counted.length ? [lista] : []), sabana.id, ...fb];
        const [porAgente, porDia, origen] = await db.batch([
          db
            .prepare(
              `WITH ${prevCte}, ${rowsCte}
               SELECT agent, SUM(m) AS total, SUM(CASE WHEN k = 1 THEN m ELSE 0 END) AS ventas,
                      SUM(k = 1) AS operaciones, COUNT(*) AS operaciones_total, SUM(status_class = 'aprobado') AS aprobadas
                 FROM s GROUP BY 1 ORDER BY ventas DESC, total DESC`,
            )
            .bind(...cteBinds),
          // El corte es el último día con ventas, pero nunca después del día en que se cargó la sábana:
          // una fecha mal escrita (p. ej. el 30 cuando la sábana es del 22) haría ver la meta MTD como la del mes completo.
          db
            .prepare(
              `SELECT MAX(CASE WHEN sale_date <= ? THEN sale_date END) AS corte, SUM(sale_date > ?) AS posteriores, MAX(sale_date) AS maxima
                 FROM bank_sales WHERE upload_id = ?${fs("")} AND sale_date LIKE ?`,
            )
            .bind(diaCarga(sabana.created_at), diaCarga(sabana.created_at), sabana.id, ...fb, `${month}%`),
          db
            .prepare(
              `WITH ${prevCte}, ${rowsCte}
               SELECT CASE WHEN sale_date IS NULL OR substr(sale_date, 1, 7) >= ? THEN 'mes' ELSE substr(sale_date, 1, 7) END AS origen,
                      SUM(CASE WHEN k = 1 THEN m ELSE 0 END) AS valor, SUM(k = 1) AS ops,
                      SUM(CASE WHEN k = 2 THEN m ELSE 0 END) AS valor_rep, SUM(k = 2) AS ops_rep
                 FROM s GROUP BY 1`,
            )
            .bind(...cteBinds, month),
        ]);
        const origenes = origen!.results as { origen: string; valor: number; ops: number; valor_rep: number; ops_rep: number }[];
        const cosecha = origenes.filter((o) => o.origen !== "mes" && n(o.ops) > 0).sort((x, y) => y.origen.localeCompare(x.origen));
        c.cosecha = {
          valor: cosecha.reduce((t, o) => t + n(o.valor), 0),
          operaciones: cosecha.reduce((t, o) => t + n(o.ops), 0),
          porMes: cosecha.map((o) => ({ month: o.origen, valor: n(o.valor), operaciones: n(o.ops) })),
        };
        c.yaContadas = { valor: origenes.reduce((t, o) => t + n(o.valor_rep), 0), operaciones: origenes.reduce((t, o) => t + n(o.ops_rep), 0) };
        const agentes = porAgente!.results as { agent: string; total: number; ventas: number; operaciones: number; operaciones_total: number; aprobadas: number }[];
        c.ventas = agentes.reduce((sum, r) => sum + n(r.ventas), 0);
        c.ventasTotales = agentes.reduce((sum, r) => sum + n(r.total), 0);
        c.operaciones = agentes.reduce((sum, r) => sum + n(r.operaciones), 0);
        c.operacionesTotales = agentes.reduce((sum, r) => sum + n(r.operaciones_total), 0);
        c.aprobadas = agentes.reduce((sum, r) => sum + n(r.aprobadas), 0);
        const corte = porDia!.results[0] as { corte: string | null; posteriores: number | null; maxima: string | null } | undefined;
        c.fechaCorte = corte?.corte ?? null;
        c.fechasPosteriores = n(corte?.posteriores) > 0 ? { filas: n(corte?.posteriores), hasta: corte!.maxima! } : null;
        c.diaDelMes = c.fechaCorte ? habiles.filter((d) => d <= c.fechaCorte!).length : 0;
        c.diasRestantes = c.diasDelMes - c.diaDelMes;
        c.ritmoDiario = c.diaDelMes ? c.ventas / c.diaDelMes : 0;
        c.proyeccion = Math.round(c.ventas + c.ritmoDiario * c.diasRestantes);
        c.porAgente = agentes.map((r) => ({
          agent: r.agent,
          ventas: n(r.ventas),
          total: n(r.total),
          operaciones: n(r.operaciones),
          aprobadas: n(r.aprobadas),
          meta: c.metaPorAgente,
          gap: c.metaPorAgente !== null ? c.metaPorAgente - n(r.ventas) : null,
          avance: c.metaPorAgente ? pct(n(r.ventas), c.metaPorAgente) : null,
          metaMTD: null,
          gapMTD: null,
          avanceMTD: null,
        }));
      } else {
        c.config.estatus = savedStatuses ?? [];
      }
      if (c.meta !== null) {
        c.avance = pct(c.ventas, c.meta);
        c.faltan = Math.max(0, c.meta - c.ventas);
        c.ritmoNecesario = c.diasRestantes > 0 ? c.faltan / c.diasRestantes : null;
        // MTD: la meta repartida por días hábiles hasta la fecha de corte.
        c.esperado = c.diasDelMes ? (c.meta * c.diaDelMes) / c.diasDelMes : null;
        c.avanceMTD = c.esperado ? pct(c.ventas, c.esperado) : null;
      }
      const share = c.diasDelMes ? c.diaDelMes / c.diasDelMes : 0;
      for (const r of c.porAgente) {
        if (r.meta === null) continue;
        r.metaMTD = r.meta * share;
        r.gapMTD = r.metaMTD - r.ventas;
        r.avanceMTD = r.metaMTD ? pct(r.ventas, r.metaMTD) : null;
      }
    }

  })();

  await Promise.all([fechasP, ventasP, baseP, llamadasP, crmP, agentesP, cumplimientoP]);
  // Penetración = clientes de la base con venta en la sábana (cruce por NIU) ÷ clientes de la base.
  if (out.llamadas) out.llamadas.penetracion = baseUnicos && ventasEnBase !== null ? pct(ventasEnBase, baseUnicos) : null;
  // Para que se vea qué nombres se unieron (solo los agentes de este mes).
  const present = new Set(out.agentes);
  out.agentesUnidos = naming.groups
    .filter((g) => present.has(g.name) && (g.variants.length > 1 || g.variants[0] !== g.name))
    .map((g) => ({ nombre: g.name, variantes: g.variants }));

  return out;
}


/** Histórico con filtro por agente: el análisis completo de cada mes (lo que cuenta por agente necesita todo el cálculo). */
async function historicoCompleto(env: Env, campaign: string, agente: string, res: Resultados): Promise<MonthSummary[]> {
    const first = await analyzeCampaign(env, campaign, null, agente, res);
    const months = first.months.slice(0, 13);
    const all = [first, ...(await Promise.all(months.slice(1).map((m) => analyzeCampaign(env, campaign, m, agente, res))))];
    const summary: MonthSummary[] = all
      .filter((a): a is CampaignAnalysis & { month: string } => Boolean(a.month))
      .map((a) => {
        const c = a.cumplimiento;
        return {
          month: a.month,
          ventas: a.ventas?.total ?? null,
          aprobadas: a.ventas?.aprobadas ?? null,
          rechazadas: a.ventas?.rechazadas ?? null,
          noDesembolsadas: a.ventas?.noDesembolsadas ?? null,
          aprobacion: a.ventas ? a.ventas.aprobacion : null,
          monto: a.ventas ? a.ventas.monto.total : null,
          montoAprobado: a.ventas ? a.ventas.monto.aprobado : null,
          base: a.base?.total ?? null,
          adicionales: a.base?.porCarga.filter((x) => x.adicional).length ?? 0,
          llamadas: a.llamadas?.total ?? null,
          registros: a.llamadas?.registros ?? null,
          contactabilidad: a.llamadas?.contactabilidad ?? null,
          ventasVici: a.llamadas?.ventasUnicas ?? null,
          penetracion: a.llamadas?.penetracion ?? null,
          unidad: c.unidad,
          meta: c.meta,
          logrado: a.ventas ? c.ventas : null,
          cumplimiento: c.meta !== null && a.ventas ? c.avance : null,
          diasHabiles: c.diasDelMes,
          hasta: a.fechas.hasta,
          acumulado: acumulado(a.month, a.ventas?.porDia ?? []),
        };
      })
      .sort((x, y) => x.month.localeCompare(y.month));
    return summary;
}

/** Meses cerrados con meta y resultado del Excel de cumplimientos oficial; los que no tienen archivos en la app también entran. */
function aplicarOficial(campaign: string, summary: MonthSummary[], oficial: Oficial | null): MonthSummary[] {
    // Meses cerrados: meta, resultado y cumplimiento del Excel de cumplimientos oficial (si se subió). Los meses que
    // no tienen archivos en la app también aparecen con esas cifras. Con filtro por agente no aplica (es de toda la campaña).
    if (oficial) {
      const hoy = diaCarga(Date.now()).slice(0, 7);
      const desde = summary[0]?.month ?? hoy;
      const [ya, ma] = hoy.split("-").map(Number) as [number, number];
      const limite = `${ma === 12 ? ya : ya - 1}-${String(ma === 12 ? 1 : ma + 1).padStart(2, "0")}`;
      const unidad = isCampaignCode(campaign) ? GOAL_UNIT[campaign] : "ventas";
      for (const of of oficial.meses) {
        if (of.campaign !== campaign || of.month >= hoy) continue;
        let s = summary.find((x) => x.month === of.month);
        if (!s) {
          // Del rango que ya muestra el histórico o de los últimos 12 meses.
          if (of.month < desde && of.month < limite) continue;
          s = {
            month: of.month, ventas: null, aprobadas: null, rechazadas: null, noDesembolsadas: null, aprobacion: null, monto: null, montoAprobado: null, base: null, adicionales: 0,
            llamadas: null, registros: null, contactabilidad: null, ventasVici: null, penetracion: null, unidad, meta: null, logrado: null, cumplimiento: null,
            diasHabiles: 0, hasta: null, acumulado: { ventas: [], monto: [] },
          };
          summary.push(s);
        }
        if (s.logrado !== null) s.logradoSabana = s.logrado;
        s.meta = of.meta ?? s.meta;
        s.logrado = of.real ?? s.logrado;
        s.cumplimiento = s.meta && s.logrado !== null ? (s.logrado / s.meta) * 100 : s.cumplimiento;
        s.oficial = true;
      }
      summary.sort((x, y) => x.month.localeCompare(y.month));
    }
    return summary;
}

/**
 * Histórico de la campaña sin repetir el análisis completo de cada mes: unas pocas consultas agrupadas por archivo
 * dan ventas, aprobación, monto, base, llamadas, contactabilidad y penetración de los 13 meses a la vez (las mismas
 * definiciones que cada pestaña), en tres viajes a la base sin importar cuántos meses haya.
 */
async function historicoRapido(env: Env, campaign: string): Promise<MonthSummary[]> {
  const db = env.DB;
  const [{ results: subidas }, ruleRow, { results: goalRows }, oficial] = await Promise.all([
    db.prepare("SELECT id, kind, month, is_addition FROM uploads WHERE campaign = ? AND is_current = 1").bind(campaign).all<{ id: string; kind: string; month: string; is_addition: number }>(),
    db.prepare("SELECT contact_rule FROM campaigns WHERE code = ?").bind(campaign).first<{ contact_rule: string }>(),
    db.prepare("SELECT month, sales_goal, agents, counted_statuses, work_days, holidays FROM goals WHERE campaign = ?").bind(campaign).all<GoalRow & { month: string }>(),
    leerOficial(env),
  ]);
  const months = [...new Set(subidas.map((u) => u.month))].sort().reverse().slice(0, 13);
  const de = (kind: string) => subidas.filter((u) => u.kind === kind && months.includes(u.month));
  const sabanas = de("sabana");
  const tipifs = de("tipif");
  const crms = de("ventas");
  const efectivo = ruleRow?.contact_rule === "sin_no_efectivo" ? "call_class IN ('venta','negativo')" : "call_class IN ('venta','negativo','no_efectivo')";
  const ids = (us: { id: string }[]) => JSON.stringify(us.map((u) => u.id));
  const enMes = (col: string) => `substr(${col}, 1, 7) = u.month`;
  const etiqueta = "COALESCE(NULLIF(TRIM(status_raw), ''), '(sin estatus)')";
  const [ventas, dias, hasta, bases, llamadas, estatus, enBase] = await db.batch([
    db
      .prepare(
        `SELECT upload_id AS id, SUM(status_class = 'aprobado') AS ap, SUM(status_class = 'rechazado') AS re, SUM(status_class = 'no_desembolsado') AS nd, SUM(status_class = 'en_proceso') AS ep,
                COALESCE(SUM(amount), 0) AS m, COALESCE(SUM(CASE WHEN status_class = 'aprobado' THEN amount END), 0) AS ma
           FROM bank_sales WHERE upload_id IN (SELECT value FROM json_each(?)) GROUP BY upload_id`,
      )
      .bind(ids(sabanas)),
    db
      .prepare(
        `SELECT b.upload_id AS id, b.sale_date AS d, COUNT(*) AS n, COALESCE(SUM(b.amount), 0) AS m
           FROM bank_sales b JOIN uploads u ON u.id = b.upload_id
          WHERE b.upload_id IN (SELECT value FROM json_each(?)) AND b.sale_date IS NOT NULL AND ${enMes("b.sale_date")} GROUP BY 1, 2`,
      )
      .bind(ids(sabanas)),
    // Hasta qué día llegan los datos del mes (sábana, llamadas y CRM).
    db
      .prepare(
        `SELECT u.month AS month, MAX(substr(x.sale_date, 1, 10)) AS h FROM bank_sales x JOIN uploads u ON u.id = x.upload_id WHERE x.upload_id IN (SELECT value FROM json_each(?1)) AND ${enMes("x.sale_date")} GROUP BY 1
         UNION ALL SELECT u.month, MAX(substr(x.called_at, 1, 10)) FROM calls x JOIN uploads u ON u.id = x.upload_id WHERE x.upload_id IN (SELECT value FROM json_each(?2)) AND ${enMes("x.called_at")} GROUP BY 1
         UNION ALL SELECT u.month, MAX(substr(x.entered_at, 1, 10)) FROM crm_sales x JOIN uploads u ON u.id = x.upload_id WHERE x.upload_id IN (SELECT value FROM json_each(?3)) AND ${enMes("x.entered_at")} GROUP BY 1`,
      )
      .bind(ids(sabanas), ids(tipifs), ids(crms)),
    // Base del mes: clientes distintos de la original y las adicionales vigentes.
    db
      .prepare(
        `SELECT u.month AS month, COUNT(DISTINCT b.niu) AS n FROM base_records b JOIN uploads u ON u.id = b.upload_id
          WHERE b.upload_id IN (SELECT value FROM json_each(?)) GROUP BY 1`,
      )
      .bind(ids(de("base"))),
    db
      .prepare(
        `SELECT upload_id AS id, COUNT(*) AS total, COUNT(DISTINCT NULLIF(niu, '')) AS registros, SUM(${efectivo}) AS efectivos,
                COUNT(DISTINCT CASE WHEN call_class = 'venta' AND niu <> '' THEN niu END) AS ventas
           FROM calls WHERE upload_id IN (SELECT value FROM json_each(?)) GROUP BY upload_id`,
      )
      .bind(ids(tipifs)),
    db.prepare(`SELECT DISTINCT upload_id AS id, ${etiqueta} AS label FROM bank_sales WHERE upload_id IN (SELECT value FROM json_each(?))`).bind(ids(sabanas)),
    // Penetración: clientes de la base del mes con venta en la sábana del mismo mes (cruce por NIU).
    db
      .prepare(
        `SELECT us.month AS month, COUNT(DISTINCT s.niu) AS n FROM bank_sales s JOIN uploads us ON us.id = s.upload_id
          WHERE s.upload_id IN (SELECT value FROM json_each(?1))
            AND EXISTS (SELECT 1 FROM base_records b JOIN uploads ub ON ub.id = b.upload_id
                         WHERE b.niu = s.niu AND ub.month = us.month AND b.upload_id IN (SELECT value FROM json_each(?2)))
          GROUP BY 1`,
      )
      .bind(ids(sabanas), ids(de("base"))),
  ]);
  const porEnBase = new Map((enBase!.results as { month: string; n: number }[]).map((r) => [r.month, n(r.n)]));
  type V = { id: string; ap: number; re: number; nd: number; ep: number; m: number; ma: number };
  type L = { id: string; total: number; registros: number; efectivos: number; ventas: number };
  const porVentas = new Map((ventas!.results as V[]).map((r) => [r.id, r]));
  const porLlamadas = new Map((llamadas!.results as L[]).map((r) => [r.id, r]));
  const porBase = new Map((bases!.results as { month: string; n: number }[]).map((r) => [r.month, n(r.n)]));
  const porHasta = new Map<string, string>();
  for (const r of hasta!.results as { month: string; h: string | null }[]) if (r.h && (!porHasta.has(r.month) || r.h > porHasta.get(r.month)!)) porHasta.set(r.month, r.h);
  const porDia = new Map<string, { date: string; ventas: number; monto: number }[]>();
  for (const r of dias!.results as { id: string; d: string; n: number; m: number }[]) porDia.set(r.id, [...(porDia.get(r.id) ?? []), { date: r.d, ventas: n(r.n), monto: n(r.m) }]);

  /* Lo que cuenta para la meta, igual que en la pestaña de cada mes: los estatus que cuentan (los guardados en Metas o
     los de la regla) y, por la cosecha, sin las ventas que ya contaron en la sábana de un mes anterior (mismo NIU y
     misma fecha). CDC y Extra suman el monto. Una consulta por mes, todas en un solo viaje a la base. */
  const unidad = isCampaignCode(campaign) ? GOAL_UNIT[campaign] : "ventas";
  const metaDe = (month: string) => {
    const goal = goalRows.find((g) => g.month === month) ?? null;
    const anterior = goalRows.filter((g) => g.month < month).sort((x, y) => y.month.localeCompare(x.month))[0];
    return { goal, config: goal ?? anterior ?? null };
  };
  const etiquetas = new Map<string, string[]>();
  for (const r of estatus!.results as { id: string; label: string }[]) etiquetas.set(r.id, [...(etiquetas.get(r.id) ?? []), r.label]);
  const medida = unidad === "monto" ? "COALESCE(amount, 0)" : "1";
  // Los meses cerrados con resultado en el Excel de cumplimientos usan ese resultado: no se calculan (es la consulta
  // más pesada, recorre las sábanas de los meses anteriores).
  const hoy = diaCarga(Date.now()).slice(0, 7);
  const conOficial = new Set((oficial?.meses ?? []).filter((o) => o.campaign === campaign && o.month < hoy && o.real !== null).map((o) => o.month));
  const conVentas = months
    .filter((month) => !conOficial.has(month))
    .map((month) => ({ month, sab: sabanas.find((u) => u.month === month) }))
    .filter((x): x is { month: string; sab: (typeof sabanas)[number] } => Boolean(x.sab));
  const logrados = conVentas.length
    ? await db.batch(
        conVentas.map(({ month, sab }) => {
          const guardados = parseList(metaDe(month).config?.counted_statuses);
          const cuentan = guardados ?? (etiquetas.get(sab.id) ?? []).filter((l) => countsForGoal(campaign as CampaignCode, l));
          if (!cuentan.length) return db.prepare("SELECT 0 AS v");
          const lista = JSON.stringify(cuentan);
          return db
            .prepare(
              `WITH prev AS (SELECT DISTINCT p.niu || '|' || COALESCE(p.sale_date, '') AS k FROM bank_sales p
                   WHERE p.upload_id IN (SELECT id FROM uploads WHERE campaign = ? AND kind = 'sabana' AND is_current = 1 AND month < ?)
                     AND COALESCE(NULLIF(TRIM(p.status_raw), ''), '(sin estatus)') IN (SELECT value FROM json_each(?)))
               SELECT COALESCE(SUM(CASE WHEN (niu || '|' || COALESCE(sale_date, '')) IN (SELECT k FROM prev) THEN 0 ELSE ${medida} END), 0) AS v FROM bank_sales
                WHERE upload_id = ? AND ${etiqueta} IN (SELECT value FROM json_each(?))`,
            )
            .bind(campaign, month, lista, sab.id, lista);
        }),
      )
    : [];
  const logradoDe = new Map(conVentas.map((x, i) => [x.month, n((logrados[i]!.results[0] as { v: number } | undefined)?.v)]));


  const summary: MonthSummary[] = months.map((month) => {
    const sab = sabanas.find((u) => u.month === month);
    const v = sab ? porVentas.get(sab.id) : undefined;
    const tip = tipifs.find((u) => u.month === month);
    const l = tip ? porLlamadas.get(tip.id) : undefined;
    const base = porBase.get(month) ?? null;
    const { goal, config } = metaDe(month);
    const dias = businessDays(month, parseDays(config?.work_days), (parseList(goal?.holidays) ?? []).filter((d) => d.startsWith(month))).length;
    const ap = n(v?.ap);
    const re = n(v?.re);
    const nd = n(v?.nd);
    const ventasVici = l ? n(l.ventas) : null;
    const meta = goal ? n(goal.sales_goal) : null;
    const logrado = sab && logradoDe.has(month) ? logradoDe.get(month)! : null;
    return {
      month,
      ventas: sab ? ap + re + nd + n(v?.ep) : null,
      aprobadas: sab ? ap : null,
      rechazadas: sab ? re : null,
      noDesembolsadas: sab ? nd : null,
      aprobacion: sab ? pct(ap, ap + re + nd) : null,
      monto: sab ? n(v?.m) : null,
      montoAprobado: sab ? n(v?.ma) : null,
      base,
      adicionales: subidas.filter((u) => u.kind === "base" && u.month === month && u.is_addition).length,
      llamadas: tip ? n(l?.total) : null,
      registros: tip ? n(l?.registros) : null,
      contactabilidad: tip ? pct(n(l?.efectivos), n(l?.total)) : null,
      ventasVici: tip ? ventasVici : null,
      penetracion: sab && base ? pct(porEnBase.get(month) ?? 0, base) : null,
      unidad,
      meta,
      logrado,
      cumplimiento: logrado !== null && meta !== null ? pct(logrado, meta) : null,
      diasHabiles: dias,
      hasta: porHasta.get(month) ?? null,
      acumulado: acumulado(month, sab ? (porDia.get(sab.id) ?? []) : []),
    };
  });
  summary.sort((x, y) => x.month.localeCompare(y.month));
  return aplicarOficial(campaign, summary, oficial);
}

export function registerAnalisis(r: Router): void {
  r.on("GET", "/analisis/:campaign", "datos:ver", async ({ env, params, url }) => {
    const campaign = params.campaign!;
    if (!isCampaignCode(campaign)) throw new HttpError(404, "Campaña desconocida.");
    const mes = url.searchParams.get("mes");
    if (mes && !/^20\d{2}-(0[1-9]|1[0-2])$/.test(mes)) throw new HttpError(400, "Mes inválido.");
    const agente = url.searchParams.get("agente")?.trim() || null;
    if (agente && agente.length > 120) throw new HttpError(400, "Nombre de agente inválido.");
    // Rango de días del mes (?desde=1&hasta=12), para comparar meses al mismo corte.
    const dia = (k: string) => {
      const v = url.searchParams.get(k);
      if (v === null || v === "") return null;
      if (!/^\d{1,2}$/.test(v) || Number(v) < 1 || Number(v) > 31) throw new HttpError(400, "Día inválido.");
      return Number(v);
    };
    const desde = dia("desde");
    const hasta = dia("hasta");
    const dias = desde !== null || hasta !== null ? { desde: desde ?? 1, hasta: hasta ?? 31 } : null;
    if (dias && dias.desde > dias.hasta) throw new HttpError(400, "El día inicial no puede ser después del final.");
    return json({ ok: true, analysis: await analyzeCampaign(env, campaign, mes, agente, undefined, dias) });
  });

  /** Histórico: un resumen por mes con los archivos vigentes de cada mes (mismo cálculo que cada pestaña). */
  r.on("GET", "/analisis/:campaign/historico", "datos:ver", async ({ env, params, url }) => {
    const campaign = params.campaign!;
    if (!isCampaignCode(campaign)) throw new HttpError(404, "Campaña desconocida.");
    const agente = url.searchParams.get("agente")?.trim() || null;
    if (agente && agente.length > 120) throw new HttpError(400, "Nombre de agente inválido.");
    const res = new Resultados(env);
    // Todo el histórico queda guardado (se recalcula solo cuando se carga o cambia algo).
    const meses = await res.obtener(`historico/${campaign}/${parteClave(agente)}.json`, () => (agente ? historicoCompleto(env, campaign, agente, res) : historicoRapido(env, campaign)), campaign);
    return json({ ok: true, agente, meses });
  });

  /** Meta de ventas y número de agentes de una campaña en un mes. */
  r.on("PUT", "/metas", "config:editar", async ({ env, req, user, soloCampana }) => {
    const b = await readJson(req);
    const campaign = requireString(b, "campaign", "la campaña", 20);
    const month = requireString(b, "month", "el mes", 7);
    if (!isCampaignCode(campaign)) throw new HttpError(400, "Campaña desconocida.");
    soloCampana(campaign);
    if (!/^20\d{2}-(0[1-9]|1[0-2])$/.test(month)) throw new HttpError(400, "Mes inválido.");
    const goal = b.salesGoal;
    const agents = b.agents ?? null;
    // Configuración: qué estatus cuentan (null = regla por defecto), días hábiles y feriados.
    const statuses = b.countedStatuses ?? null;
    if (statuses !== null && (!Array.isArray(statuses) || statuses.length > 100 || statuses.some((x) => typeof x !== "string" || x.length > 120))) {
      throw new HttpError(400, "La lista de estatus que cuentan no es válida.");
    }
    const workDays = b.workDays ?? [...DEFAULT_WORK_DAYS];
    if (!Array.isArray(workDays) || !workDays.length || workDays.some((d) => !Number.isInteger(d) || d < 0 || d > 6)) {
      throw new HttpError(400, "Elige al menos un día de la semana que se trabaje.");
    }
    const holidays = b.holidays ?? [];
    if (!Array.isArray(holidays) || holidays.length > 31 || holidays.some((d) => typeof d !== "string" || !d.startsWith(month) || !/^\d{4}-\d{2}-\d{2}$/.test(d))) {
      throw new HttpError(400, "Los feriados deben ser fechas del mismo mes.");
    }
    // CDC y Extra ponen la meta en dólares: se permiten montos grandes y centavos.
    if (typeof goal !== "number" || !Number.isFinite(goal) || goal < 0 || goal > 1_000_000_000) throw new HttpError(400, "La meta debe ser un número positivo.");
    if (agents !== null && (typeof agents !== "number" || !Number.isInteger(agents) || agents < 1 || agents > 1000)) {
      throw new HttpError(400, "El número de agentes debe ser un entero mayor que cero.");
    }
    await env.DB.prepare(
      `INSERT INTO goals (campaign, month, sales_goal, agents, counted_statuses, work_days, holidays, updated_by, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT (campaign, month) DO UPDATE SET sales_goal = excluded.sales_goal, agents = excluded.agents,
         counted_statuses = excluded.counted_statuses, work_days = excluded.work_days, holidays = excluded.holidays,
         updated_by = excluded.updated_by, updated_at = excluded.updated_at`,
    )
      .bind(
        campaign,
        month,
        goal,
        agents,
        statuses === null ? null : JSON.stringify([...new Set(statuses.map((x: string) => x.trim()))]),
        [...new Set(workDays as number[])].sort().join(","),
        JSON.stringify([...new Set(holidays as string[])].sort()),
        user.username,
        Date.now(),
      )
      .run();
    await audit(env, user.username, "meta_actualizada", `${campaign}:${month}`, { meta: goal, agentes: agents, estatus: statuses, diasSemana: workDays, feriados: holidays });
    return json({ ok: true });
  });
}
